# iSpammer

<b>Introducing iSpammer Created by Mr. SparX
It's a SMS Bomber only For Indian Numbers
Full Tutorial Video</b>
<a href='https://youtu.be/vcYESgi_Mh4'>Tutorial of iSpammer</a>

<b>Steps:</b><br>
```
apt install python3 curl git -y
git clone https://github.com/MrSp4rX/iSpammer.git
cd iSpammer
pip3 install -r requirements.txt
python3 iSpammer.py -m Number_of_messages -t target's_mobile_number
```
<br>For Example:<br>

```
python3 iSpammer.py -m 100 -t 9797979797
```

<br><br>
<b>Credits:<br></b>

<a href='https://github.com/TheSpeedX'>SpeedX<br></a>
<a href='https://github.com/R37r0-Gh057'>R37r0 Gh057<br></a>
<a href='https://github.com/brijeshpatel26667'>Brizzesh<br></a>
<a href='https://www.instagram.com/encryptednoob/' target=_blank>Encrypt3dn00b</a><br>
<br>
<b>Works:<br></b>
<br>
SpeedX and R37r0 Gh057 worked as Code Error Solver.<br><br>
Encrypt3dn00b worked as API Finder.<br><br>
Brizzesh worked for Creating a Good and Stylish Banner because I don't know How to create Banners XD and They created this Tool's Intro Video<br><br>
<br>
<strong>Telegram Group: </strong><p>http://bit.do/ispammer</p>
<br>
<b><i>Using Our Creation in Wrong way is not permitted.<br>
If you do then You will responsible for yourself.</i></b>
